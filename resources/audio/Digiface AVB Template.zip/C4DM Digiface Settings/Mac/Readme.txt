Copy .plist to ~/Library/Preferences and replace


1. Open finder
2. Cmd+G or Go to Folder, and navigate to ~/Library/Preferences
3. Copy .plist to the root of this folder